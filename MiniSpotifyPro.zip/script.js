const audio=document.getElementById('audio');
const upload=document.getElementById('upload');
const playlist=document.getElementById('playlist');
const search=document.getElementById('search');
const title=document.getElementById('title');
const progress=document.getElementById('progress');
let songs=[],current=0,repeat=false;

function render(list){
 playlist.innerHTML='';
 list.forEach((s,i)=>{
  let li=document.createElement('li');
  li.textContent=s.name;
  li.onclick=()=>playSong(i);
  playlist.appendChild(li);
 });
}

upload.onchange=e=>{
 songs=[...e.target.files];
 render(songs);
 if(songs.length) playSong(0);
};

function playSong(i){
 current=i;
 audio.src=URL.createObjectURL(songs[i]);
 title.textContent=songs[i].name;
 audio.play();
 document.getElementById('play').textContent='⏸';
}

document.getElementById('play').onclick=()=>{
 if(audio.paused){audio.play();play.textContent='⏸';}
 else{audio.pause();play.textContent='▶';}
};

document.getElementById('next').onclick=()=>{
 if(songs.length) playSong((current+1)%songs.length);
};

document.getElementById('prev').onclick=()=>{
 if(songs.length) playSong((current-1+songs.length)%songs.length);
};

document.getElementById('shuffle').onclick=()=>{
 if(songs.length) playSong(Math.floor(Math.random()*songs.length));
};

document.getElementById('repeat').onclick=()=> repeat=!repeat;

audio.onended=()=>{
 if(repeat) playSong(current);
 else if(songs.length) playSong((current+1)%songs.length);
};

audio.ontimeupdate=()=>{
 progress.max=audio.duration||0;
 progress.value=audio.currentTime||0;
};

progress.oninput=()=>audio.currentTime=progress.value;

volume.oninput=e=>audio.volume=e.target.value;

search.oninput=()=>{
 const q=search.value.toLowerCase();
 render(songs.filter(s=>s.name.toLowerCase().includes(q)));
};

const favBtn=document.getElementById('fav');
favBtn.onclick=()=>{
 if(!songs[current]) return;
 let f=JSON.parse(localStorage.getItem('fav')||'[]');
 const n=songs[current].name;
 if(!f.includes(n)) f.push(n);
 localStorage.setItem('fav',JSON.stringify(f));
 alert('Favoritada!');
};

theme.onclick=()=>document.body.classList.toggle('light');
