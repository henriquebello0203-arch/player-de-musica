# Mini Spotify Pro
Projeto HTML/CSS/JS para GitHub.